import evaluation

path = "V:\\Uni4\\SoloProject\\Outputs 2\DT\\4_3_600_5_3_5_C_1\\500_0.00001_5_15_25_3\\DT_None_20_2"

evaluation.feature_ranking(path)
evaluation.test_ranking(path)