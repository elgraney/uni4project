THREADS = 10
feature0 = "category"

training_set_proportion = 3/4
validation_set_proportion = 0
test_set_proportion = 1/4 # cumulative on validation

training_repetitions = 10

seed = 501